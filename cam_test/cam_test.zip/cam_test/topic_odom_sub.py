import pymssql
import rclpy
import time
import numpy as np
import cv2
from scipy.spatial.transform import Rotation as R
from rclpy.node import Node
from nav_msgs.msg import Odometry
from sensor_msgs.msg import CompressedImage,Image   # 图像消息类型
from cv_bridge import CvBridge


def send_to_sql(data, table_name):
    conn = pymssql.connect(server='192.168.2.95', user='sa', password='pass', database='ROS2')
    cursor = conn.cursor()
    #sql = f"UPDATE {table_name} SET position_x = '(%s)', position_y = '(%s)', position_z = '(%s)',position_pitch = '(%s)',position_yaw = '(%s)',position_roll = '(%s)',T99 = '(%s)'"
    sql = f"UPDATE {table_name} SET position_x = '{data['position_x']}',position_y = '{data['position_y']}',position_z = '{data['position_z']}',position_pitch='{data['position_pitch']}',position_yaw='{data['position_yaw']}',position_roll='{data['position_roll']}',image_data = (%s),T99 = '{time.strftime('%Y-%m-%d %H:%M:%S')}';"
    print(sql)
    #cursor.execute(sql,(data['position_x'],data['position_y'],data['position_z'],time.strftime('%Y-%m-%d %H:%M:%S')))
    cursor.execute(sql,(data['image_data']))
    conn.commit()
    conn.close()

class DataCollector(Node):
    def __init__(self):
        super().__init__('data_collector')
        #self.odom_subscriber = self.create_subscription(Odometry, '/odom', self.odom_callback, 10)
        #self.odom_data = None        
        #self.timer = self.create_timer(0.5, self.timer_callback)
        
        self.subscriptions_topic = []
        self.data_store = {}
        self.bridge = CvBridge()
        topics = ['/odom', '/camera/image_raw/compressed']  # 訂閱的topics列表
        for topic in range(len(topics)):
            if topic == 0:
                sub = self.create_subscription(Odometry, topics[topic],lambda msg,topic=topics[topic]: self.odom_callback(msg, topic), 10)
                self.subscriptions_topic.append(sub)
            elif topic == 1:
                sub = self.create_subscription(CompressedImage,topics[topic],lambda msg,topic=topics[topic]: self.listener_callback(msg, topic), 10)
                self.subscriptions_topic.append(sub)
                
        self.timer = self.create_timer(0.5, self.timer_callback)
        

    def odom_callback(self, msg,topic):
        self.data_store[topic] = msg
        #print(msg)
    	#self.odom_data = msg
        #data = {
        #    'position_x': msg.pose.pose.position.x,
        #    'position_y': msg.pose.pose.position.y,
        #    'position_z': msg.pose.pose.position.z
        #}
        #send_to_sql(data, 'ODOM')
        self.get_logger().info(f'position_x: {msg.pose.pose.position.x},position_y : {msg.pose.pose.position.y},position_z : {msg.pose.pose.position.z}') 
        
    def listener_callback(self, msg,topic):
        # 將ROS消息中的二進制圖像數據保存到數據庫中
        self.data_store[topic] = np.frombuffer(msg.data, np.uint8).tobytes()
        #print(np.frombuffer(msg.data, np.uint8).tobytes())
        #np_arr = np.frombuffer(msg.data, np.uint8)
    	# 解碼圖像數據

        #binary_data = np_arr.tobytes()
        #self.data_store[topic] = binary_data


    def timer_callback(self):
        print("g0 j2")
        # 每0.5秒處理一次數據
        if self.data_store != {}:
            #print(self.data_store)
            
            orientation_q = self.data_store['/odom'].pose.pose.orientation
            quaternion = (
                orientation_q.x,
                orientation_q.y,
                orientation_q.z,
                orientation_q.w
            )

            # 将四元数转换为欧拉角
            euler = R.from_quat(quaternion).as_euler('xyz', degrees=False)
            roll = euler[0]
            pitch = euler[1]
            yaw = euler[2]
            
            data = {
                'position_x': self.data_store['/odom'].pose.pose.position.x,
                'position_y': self.data_store['/odom'].pose.pose.position.y,
                'position_z': self.data_store['/odom'].pose.pose.position.z,
                'position_pitch' : pitch,
                'position_yaw'   : yaw,
                'position_roll'   : roll,
                'image_data': self.data_store['/camera/image_raw/compressed']
            }
            send_to_sql(data, 'ODOM')
            self.get_logger().info(f"position_x: {data['position_x']}, position_y: {data['position_y']}, position_z: {data['position_z']}")
            # 處理完後清除數據
            self.odom_data = None

def main(args=None):
    rclpy.init(args=args)
    data_collector = DataCollector()
    rclpy.spin(data_collector)
    data_collector.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
